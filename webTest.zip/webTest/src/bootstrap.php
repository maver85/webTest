<?php
define('APP_ROOT', dirname(__FILE__, 2));

require APP_ROOT . '/src/functions.php';                 
require APP_ROOT . '/config/config.php';                 
require APP_ROOT . '/vendor/autoload.php';               

use WebTest\Container\Container;

$container = new Container($dsn, $username, $password); 
unset($dsn, $username, $password);  

$loader = new Twig\Loader\FilesystemLoader(APP_ROOT . '/templates');
$twig   = new Twig\Environment($loader, []);

$session = $container->getSession();                           
$twig->addGlobal('session', $session); 

$twig->addGlobal('doc_root', DOC_ROOT);