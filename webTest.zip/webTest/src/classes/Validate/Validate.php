<?php
namespace WebTest\Validate;                      

class Validate
{
    public static function isText(string $string, int $min = 0, int $max = 1000): bool
    {
        $length = mb_strlen($string);
        return ($length >= $min and $length <= $max);
    }

    public static function isEmail($email): bool
    {
        return (filter_var($email, FILTER_VALIDATE_EMAIL)) ? true : false;
    }

    public static function isPassword($password)
    {
        if ( mb_strlen($password) >= 8                     
            and preg_match('/[A-Z]/', $password)             
            and preg_match('/[a-z]/', $password)             
            and preg_match('/[0-9]/', $password)             
        ) {
            return true;                                     
        }
        return false;                                     
    }
}