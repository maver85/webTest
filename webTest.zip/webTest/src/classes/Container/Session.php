<?php
namespace WebTest\Container;                                   

class Session
{                                                        
    public $id;                                          
    public $name;                                      

    public function __construct()
    {                                                    
        session_start();                                 
        $this->id       = $_SESSION['id'] ?? 0;          
        $this->name = $_SESSION['name'] ?? '';   
    }

    // Create new session
    public function create($member)
    {
        session_regenerate_id(true);                     
        $_SESSION['id']       = $member['id'];            
        $_SESSION['name'] = $member['name'];     
    }

    // Update existing session - alias for create()
    public function update($member)
    {
        $this->create($member);                          
    }

    // Delete existing session
    public function delete()
    {
        $_SESSION = [];                                  
        $param    = session_get_cookie_params();         
        setcookie(session_name(), '', time() - 2400, $param['path'], $param['domain'],
            $param['secure'], $param['httponly']);       
        session_destroy();                               
    }
}