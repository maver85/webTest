<?php
namespace WebTest\Container;

class Member
{
    protected $db;                                       

    public function __construct(Database $db)
    {
        $this->db = $db;                                 
    }

    // Get individual member by id
    public function get(int $id)
    {
        $sql = "SELECT id, name, email, dob, password 
                  FROM users
                 WHERE id = :id;";                       
        return $this->db->runSQL($sql, [$id])->fetch(); 
    }

    // Get individual member data using their email
    public function getIdByEmail(string $email)
    {
        $sql = "SELECT id
                  FROM users
                 WHERE email = :email;";                         
        return $this->db->runSQL($sql, [$email])->fetchColumn(); 
    }

    // Login: returns member data if authenticated, false if not
    public function login(string $email, string $password)
    {		
        $sql = "SELECT id, name, email, dob, password 
                  FROM users 
                 WHERE email = :email;";                         
        $member = $this->db->runSQL($sql, [$email])->fetch();   
        if (!$member) {                                         
            return false;                                       
        }                                                        
        $authenticated = password_verify($password, $member['password']); 
		
		
		echo var_dump($password);
		echo var_dump($member['password']);
		
		
		echo var_dump($authenticated);
		
		
        return ($authenticated ? $member : false);               
    }

    // Create a new member
    public function create(array $member): bool
    {
        $member['password'] = password_hash($member['password'], PASSWORD_DEFAULT);  
        try {                                                          
            $sql = "INSERT INTO users (name, email, dob, password) 
                    VALUES (:name, :email, :dob, :password);"; 
            $this->db->runSQL($sql, $member);                          
            return true;                                               
        } catch (\PDOException $e) {                                   
            if ($e->errorInfo[1] === 1062) {                           
                return false;                                          
            }                                                         
            throw $e;                                                  
        }
    }

    // Update an existing member
    public function update(array $member): bool
    {             
        try {                                                         
            $sql = "UPDATE users 
                       SET name = :name, email = :email, dob = :dob
                     WHERE id = :id;";                                
            $this->db->runSQL($sql, $member);                         
            return true;                                             
        } catch (\PDOException $e) {                                  
            if ($e->errorInfo[1] == 1062) {                           
                return false;                                         
            }                                                        
            throw $e;                                                 
        }
    }

    // Update member password
    public function passwordUpdate(int $id, string $password): bool
    {
        $hash = password_hash($password, PASSWORD_DEFAULT);           
        $sql = 'UPDATE users 
                   SET password = :password 
                 WHERE id = :id;';                                    
        $this->db->runSQL($sql, ['id' => $id, 'password' => $hash,]); 
        return true;                                                  
    }
}