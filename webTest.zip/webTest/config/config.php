<?php
$folder   = substr(__DIR__, strlen($_SERVER['DOCUMENT_ROOT']));
$parent_folder = dirname($folder);
define("DOC_ROOT", $parent_folder . '/public/');

$type     = 'mysql';                 
$server   = 'localhost';

$databaseName = 'my_new_database';             

$username = 'root'; // Enter YOUR username here
$password = '';     // Enter YOUR password here

$options  = [                       
	PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
	PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
	PDO::ATTR_EMULATE_PREPARES   => false,
];                                                                  

$dsn = "$type:host=$server";

// Connect to server
try {                                                               
	$pdo = new PDO($dsn, $username, $password, $options);
} catch (PDOException $e) {                                         
	throw new PDOException($e->getMessage(), $e->getCode());        
}

// Check if database and tables already exist. If so, just connect to the DB.
try {
	$is_tables_created = $pdo->query("SELECT TABLE_NAME
										FROM INFORMATION_SCHEMA.TABLES
										WHERE TABLE_SCHEMA = 'my_new_database'
										AND TABLE_NAME IN ('users');");
								
	if ($is_tables_created->fetch()) 
	{
		// Connect to DB.
		$dsn = "mysql:host=$server;dbname=$databaseName;charset=utf8mb4";

		try {
			$pdo = new PDO($dsn, $username, $password);
		} catch (PDOException $e) {
			die("Error connecting to database '$databaseName': " . $e->getMessage());
		}
		
		return;
	}									
} catch(PDOException $e) {
	die("Error checking tables in  '$databaseName': " . $e->getMessage());
}

// Create DB
try {
	$pdo->query("CREATE DATABASE IF NOT EXISTS `$databaseName`");
} catch (PDOException $e) {
	die("Error creating database: " . $e->getMessage());
}

// Connect to DB.
$dsn = "mysql:host=$server;dbname=$databaseName;charset=utf8mb4";

try {
	$pdo = new PDO($dsn, $username, $password);
} catch (PDOException $e) {
	die("Error connecting to database '$databaseName': " . $e->getMessage());
}

// Create table 'users'.
try {
	$pdo->query("
		CREATE TABLE IF NOT EXISTS `users` (
			`id` int(11) NOT NULL,
			`name` VARCHAR(255) NOT NULL,
			`email` VARCHAR(255) NOT NULL,
			`dob` TIMESTAMP NOT NULL,
			`password` VARCHAR(255) NOT NULL
		) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
	");
	
	$pdo->query("
		ALTER TABLE `users`
			ADD PRIMARY KEY (`id`),
			ADD UNIQUE KEY `email` (`email`);
	");
		
	$pdo->query("
		ALTER TABLE `users`
			MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
	");
} catch (PDOException $e) {
	die("Error creating table 'users': " . $e->getMessage());
}

$pdo=null;