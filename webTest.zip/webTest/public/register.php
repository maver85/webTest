<?php
declare(strict_types = 1);                               
include '../src/bootstrap.php';   

use WebTest\Validate\Validate;   
                       
$member = [];                                            
$errors = [];                                            

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $member['name']     = $_POST['name'];            
    $member['email']    = $_POST['email'];             
    $member['dob']      = $_POST['dob_a'];               
    $member['password'] = $_POST['password'];            
    $confirm            = $_POST['confirm'];             

    $errors['name'] = Validate::isText($member['name'], 1, 254)
        ? '' : 'Name must be 1-254 characters';
    $errors['email']  = Validate::isEmail($member['email'])
        ? '' : 'Please enter a valid email';
    $errors['dob']    = $member['dob']
        ? '' : 'Please enter a date of birth';
    $errors['password'] = Validate::isPassword($member['password'])
        ? '' : 'Passwords must be at least 8 characters and have:<br> 
                A lowercase letter<br>An uppercase letter<br>A number 
                <br>And a special character';
    $errors['confirm']  = ($member['password'] = $confirm)
        ? '' : 'Passwords do not match';
    $invalid            = implode($errors);

    if (!$invalid) {
		$result = $container->getMember()->create($member);
         if ($result === false) {                             
            $errors['email'] = 'Email address already used'; 
        } else {                                             
            redirect('login.php', ['success' => 'Thanks for joining! Please log in.']); 
        }
    }
}

$data['member']     = $member;                               
$data['errors']     = $errors;                               

echo $twig->render('register.html', $data);                  