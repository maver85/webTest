<?php
declare(strict_types = 1);
include '../src/bootstrap.php';

$session = $container->getSession();
$data['session'] = $session;

echo $twig->render('nav.html', $data);