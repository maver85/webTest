<?php
declare(strict_types = 1);                                          
use WebTest\Validate\Validate;                                      

include '../src/bootstrap.php';                                     

$errors = [];                                                       

$id = $container->getSession()->id;

if ($_SERVER['REQUEST_METHOD'] == 'POST') {                     
    $password = $_POST['password'];                             
    $confirm  = $_POST['confirm'];                              

    $errors['password'] = Validate::isPassword($password)
        ? '' : 'Passwords must be at least 8 characters and have:<br> 
                A lowercase letter<br>An uppercase letter<br>A number 
                <br>And a special character';                   
    $errors['confirm']  = ($password === $confirm)
        ? '' : 'Passwords do not match';                        
    $invalid = implode($errors);                                

    if ($invalid) {                                             
        $errors['message'] = 'Please enter a valid password.';  
    } else {                                                    
        $container->getMember()->passwordUpdate($id, $password);      
        $member  = $container->getMember()->get($id);                 
        redirect('member.php', ['id' => $id,'success' => 'Password updated']); 
    }
}

$data['errors']     = $errors;                                   

echo $twig->render('password-reset.html', $data);               