$('#login-form-submit').on('submit', function(e) {
	e.preventDefault();
	const data = $(this).serialize();
	$.post('/webTest/public/login.php', data, function(response){
		$('#content').html(response);
	});
}); 