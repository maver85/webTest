$('form.password-reset').on('submit', function(e){
	e.preventDefault();
	const pass = $('#password').val();
	const confirm = $('#confirm').val();
	$.post('/webTest/public/password-reset.php', {'password': pass, 'confirm': confirm}, function(response){
		$('#content').html(response);
	});
});