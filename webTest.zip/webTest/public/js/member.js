$.get('/webTest/public/nav.php', [], function(response){
	$('#nav').html(response);
}).then(function(){
	$('a#profile-button').click(function(e){
		e.preventDefault();
		const sess_id = $('div.profile-logout').data('value');
		$.get('/webTest/public/member.php', {'id': sess_id}, function(response){
			$('#content').html(response);
		});
	});
}).then(function(){
	$('#editButton').click(function() {
		const inputField = $('#name,#email,#dob');
		if (inputField.is('[readonly]')) {
			inputField.prop('readonly', false);
			initilize_datepicker();
			$(this).text('Save'); // Or "Done"
			$(this).removeClass('btn-outline-secondary').addClass('btn-success'); // Change button style
			$('button.btn-success').click(function(){
				const name = $('input#name').val();
				const email = $('input#email').val();
				const dob = $('input#dob_a').val();
				$.post('/webTest/public/member-edit-profile.php', {'name': name, 'email': email, 'dob_a': dob}, function(response){
					$('#content').html(response);
				});
			});
		}
	});
}).then(function(){
	$('#password-change').click(function(){
		$.get('/webTest/public/password-reset.php', {}, function(response){
			$('#content').html(response);
		});
	});
});








