	function initilize_datepicker() {
		$('#datepicker input').datepicker({
			dateFormat: 'dd/mm/yy',
			altField: '#dob_a',
			altFormat: 'yy-mm-dd',
			onSelect: function(dateText, inst) {
				const selectedDate = $(this).datepicker('getDate');
				
				const formattedDateForDatabase = $.datepicker.formatDate('yy-mm-dd', selectedDate);
				const formattedDateForDisplay = $.datepicker.formatDate('MM dd, yy', selectedDate);
				
				$("#dob_a").val(formattedDateForDatabase); // Update the hidden input
			},
			autoclose: true,
			defaultDate: '02/02/2000',
			yearRange: '1965:2007',
			changeYear: true,
			changeMonth: true
		}); 
	}
		
	$('#login-button').click(function() {
		$.ajax({
			url: '/webTest/public/login.php', 
			type: 'GET', 
			data: {
			}, 
			success: function(response) {
				$('#content').html(response); 
				
			},
			error: function(jqXHR, textStatus, errorThrown) {
				console.error("AJAX Error:", textStatus, errorThrown);
			}
		});
	}); 
	
	$('#register-button').click(function() {
		$.ajax({
			url: '/webTest/public/register.php', 
			type: 'GET', 
			data: {}, 
			success: function(response) {
				$('#content').html(response); 
				initilize_datepicker();
			},
			error: function(jqXHR, textStatus, errorThrown) {
				console.error("AJAX Error:", textStatus, errorThrown);
			}
		});
	}); 

	$('a#profile-button').click(function(e) {
		e.preventDefault();
		$.ajax({
			url: '/webTest/public/member.php', 
			type: 'GET', 
			data: {'id': $(this).closest('.profile-logout').data('value')}, 
			success: function(response) {
				$('#content').html(response); 
			},
			error: function(jqXHR, textStatus, errorThrown) {
				console.error("AJAX Error:", textStatus, errorThrown);
			}
		});
	}); 

