<?php
declare(strict_types = 1);
include '../src/bootstrap.php';

$data['page']['title'] = 'WebTest';

echo $twig->render('home.html', $data);