<?php
declare(strict_types = 1);

include '../src/bootstrap.php';

$container->getSession()->delete();

redirect('home.php');