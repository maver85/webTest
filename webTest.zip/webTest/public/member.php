<?php
declare(strict_types = 1);                               
include '../src/bootstrap.php';                          

$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
if ($id === false) {                                             
    include APP_ROOT . '/public/page-not-found.php';     
}

$member = $container->getMember()->get($id);                   

$data['member']      = $member;                                  
$data['success']     = $_GET['success'] ?? '';                   

$session = $container->getSession();
$data['session'] = $session;

echo $twig->render('member.html', $data);                        