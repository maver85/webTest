<?php
declare(strict_types = 1);                               
use WebTest\Validate\Validate;                           

include '../src/bootstrap.php';                          

$id = $container->getSession()->id;                            
if ($id === 0) {                                         
    redirect('login.php');                               
}

$errors  = [];                                           

if ($_SERVER['REQUEST_METHOD'] != 'POST') {              
    $member  = $container->getMember()->get($container->getSession()->id); 
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {              
    $member['id']       = $container->getSession()->id;        
    $member['name'] 	= $_POST['name'];            
    $member['email']  = $_POST['email'];             
    $member['dob']    = $_POST['dob_a'];               

    // Validate form data
    $errors['name'] = Validate::isText($member['name'], 1, 254) ? '' :
        'Forename should be between 1 and 254 characters';
    $errors['email']    = Validate::isEmail($member['email']) ? '' :
        'Please enter a valid email address';

    $invalid = implode($errors);                            
    if ($invalid) {                                         
        $errors['message'] = 'Please correct form errors';  
    } else {                                                
        $result = $container->getMember()->update($member);       
        if ($result === false) {                            
            $errors['message'] = 'Email already in use';    
        } else {                                            
            $container->getSession()->update($member);            
            redirect('member.php', ['id'=>$member['id'], 'success'=>'Profile saved',]); 
        }
    }
}

$data['member']     = $member;                         
$data['errors']     = $errors;                         

echo $twig->render('member.html', $data); 