<?php
require 'vendor/autoload.php';

Flight::redirect('/public/home.php');

Flight::start();